'use strict';
module.exports = {
	user:{
	defaultUser: require('../../assets/images/temp/1.png')
	}
};
