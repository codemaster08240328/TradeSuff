'use strict';

module.exports = {
    BaseStyle: require('./BaseStyle'),
    Colors: require('./Colors'),
    Images: require('./Images'),
};
