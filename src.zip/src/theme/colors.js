const colors = {
    backgroundPrimary: '#fff',
    backgroundSecondary : '#eee',
    whiteColor : '#fff',
    blackColor:'#000',    
    
    darkGrayColor: '#767676',
    greenColor: '#7aaf0d',
    orangeColor: '#f99910',
    lightGrayColor:'#e3e3e3',
    verylightGrayColor: '#f5f5f5',
    orange: '#f79a0e'

  };
  
  export default colors;