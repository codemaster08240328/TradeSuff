"use strict"

let colors = {
    Transparent: 'transparent',
    White:"#fff",
    Black:'rgb(54,54,74)',
    VeryLightGrey: '#f5f5f5',
	LightGrey: '#e3e3e3',
	MediumGrey: '#d4d4d4',
	DarkGrey: '#767676',
	Orange: '#f79a0e',
	Green: '#79af13'

};

module.exports =  colors;